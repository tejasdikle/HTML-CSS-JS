const mysql = require('mysql');
var mysqlconnection=mysql.createConnection({

    host:'127.0.0.1',
    user:'root',
    password:'Tejas#2001',
    port:3306,
    database:'booksstore'
})
mysqlconnection.connect((err)=>{

    if(err)
    {
        console.log("Connection Failed");
    }
    else{
        console.log("Connection Successfully");
    }
})
module.exports=mysqlconnection;