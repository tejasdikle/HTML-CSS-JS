const express = require('express');
const router = express.Router();
const Connection = require('../db/dbconnection');

router.get("/books", function(req, resp) {
    Connection.query("SELECT * FROM books", (err, data, fields) => {
        if (err) {
            console.log(err);
            resp.status(500).send("<h3>No data found</h3>");
        } else {
            console.log(data);
            resp.render("index", { Bookdata: data });
        }
    });
});

router.get("/displayaddform", function(req, resp) {
    resp.render("addBooks");
});

router.post("/addBooks", function(req, resp) {
    Connection.query("INSERT INTO books (book, author, price) VALUES (?, ?, ?)", [req.body.name, req.body.author, req.body.price], (err, data) => {
        if (err) {
            console.log(err);
            resp.status(500).send("<h3>No data Found</h3>");
        } else {
            console.log(data);
            resp.redirect("/books");
        }
    });
});

router.get("/delete/:id", function(req, resp) {
    Connection.query("DELETE FROM books WHERE id=?", [req.params.id], function(err, data) {
        if (err) {
            console.log(err);
            resp.status(500).send("<h3>No data found</h3>");
        } else {
            console.log(data);
            resp.redirect("/books");
        }
    });
});

router.get("/edit/:id", function(req, resp) {
    Connection.query("SELECT * FROM books WHERE id=?", [req.params.id], function(err, data) {
        if (err) {
            console.log(err);
            resp.status(500).send("<h3>No data found</h3>");
        } else {
            console.log(data);
            resp.render("edit", { book: data[0] });
        }
    });
});


router.post("/update", function(req, resp) {
    Connection.query("update books SET book=?, author=?, price=? WHERE id=?", [req.body.book, req.body.author, req.body.price, req.body.id], function(err, data) {
        if (err) {
            console.log(err);
            resp.status(500).send("<h3>Error updating data</h3>");
        } else {
            console.log(data);
            resp.redirect("/books");
        }
    });
});


module.exports = router;
