const express = require('express');
const app=express();
const bodyparser = require("body-parser");
const path = require("path");
const routes=require("./routes/router");


app.set("views",path.join(__dirname,"views"));
app.set("view engine", "ejs");
app.use(bodyparser.urlencoded({extended:false}))
app.use("/",routes);
app.listen(3004,function(){
    console.log("server start at this port 3004");
})
module.exports=app;
