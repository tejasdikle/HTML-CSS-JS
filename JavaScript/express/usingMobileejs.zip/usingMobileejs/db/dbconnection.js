const mysql = require('mysql');
var mysqlconnection=mysql.createConnection({

    host:'127.0.0.1',
    user:'root',
    password:'Tejas#2001',
    port:3306,
    database:'reactmobile'
})
mysqlconnection.connect((err)=>{

    if(err){
    console.log("Connection failed");
    }
    else{
        console.log("Successfully connected");
    }
});
module.exports=mysqlconnection;