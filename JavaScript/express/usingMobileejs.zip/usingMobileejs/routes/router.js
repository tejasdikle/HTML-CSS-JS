const express = require('express');
var router =express.Router();
var Connection=require('../db/dbconnection');
router.get("/mobile",function(req,resp){

    Connection.query("select * from Mobile",(err,data,fields)=>{

        if(err)
        {
            console.log(err);
            resp.status(500).send("<h3>No data found</h3>");
        }
        else{
            console.log(data);
            resp.render("index",{Mobiledata:data});
        }
    })
});
router.get("/displayaddform",function(req,resp){

    resp.render("addMobile");
})
router.post("/addMobile",function(req,resp){
    Connection.query("insert into Mobile values(?,?,?,?,?,?)",[req.body.id,req.body.name,req.body.brand,req.body.color,req.body.dateOfPurches,req.body.price],(err,data)=>{
        if(err)
        {
            console.log(err);
            resp.status(500).send("<h3>No data Found</h3>")
        }
        else{
            console.log(data);
            resp.redirect("/mobile");

        }
    })
});
router.get("/delete/:id",function(req,resp){
    connection.query("delete from Mobile where id=?",[req.params.id],function(err,data){
        if(err){
            console.log(err);
            resp.status(500).send("<h3>no data found</h3>")
           }else{
            console.log(data);
            resp.redirect("/mobile");
           }

    })
});
router.get("/edit/:id",function(req,resp){
    connection.query("select * from Mobile where id=?",[req.params.id],function(err,data){
        if(err){
            console.log(err);
            resp.status(500).send("<h3>no data found</h3>")
           }else{
            
            console.log(data);
            resp.render("editMobile",{Mobo:data[0]})
           }
    })

});

router.post("/update",function(req,resp){
    connection.query("update Mobile set name=?,brand=?,color=?,price=? where id=?",[req.body.name,req.body.brand,req.body.color,req.body.price,req.body.id],function(err,data){
        if(err){
            console.log(err);
            resp.status(500).send("<h3>no data updated</h3>")
           }else{
            console.log(data);
            resp.redirect("/mobile");
           }

    })

})

//this is same object rotes in app.js
module.exports=router;