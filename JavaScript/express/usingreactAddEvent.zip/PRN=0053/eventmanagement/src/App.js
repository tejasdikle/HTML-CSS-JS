import React, { useState } from "react";
import AddEvent from "./component/AddEvent";
import EventList from "./component/EventList";
import "bootstrap/dist/css/bootstrap.min.css";

function App() {
  const [events, setEvents] = useState([]);

  const addEvent = (newEvent) => {
    setEvents([...events, newEvent]);
  };

  return (
    <div className="container mt-4">
      <AddEvent addEvent={addEvent} setEvents={setEvents} />
      <EventList events={events} setEvents={setEvents} />
    </div>
  );
}

export default App;
