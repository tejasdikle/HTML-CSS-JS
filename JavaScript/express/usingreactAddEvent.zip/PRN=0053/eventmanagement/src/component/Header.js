const Header=()=>{

    return(

        <div>
            <h1>Event Management </h1>
        </div>
    )
}
export default Header;