import React, { useState } from "react";

const AddEvent = ({ addEvent }) => {
  const [event, setEvent] = useState({
    title: "",
    description: "",
    dueDate: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEvent({ ...event, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("http://localhost:3000/events/new", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(event),
      });

      if (response.ok) {
        const newEvent = await response.json();
        alert(
          `Event added successfully:\nTitle: ${newEvent.event.title}\nDescription: ${newEvent.event.description}\nDue Date: ${newEvent.event.dueDate}`
        );
        addEvent(newEvent.event);
        setEvent({ title: "", description: "", dueDate: "" });
      } else {
        alert("Error adding event");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred while adding the event");
    }
  };

  return (
    <div className="container mt-4">
      <h2>Add Event</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="title" className="form-label">
            Event Title
          </label>
          <input
            type="text"
            className="form-control"
            id="title"
            name="title"
            value={event.title}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="description" className="form-label">
            Description
          </label>
          <textarea
            className="form-control"
            id="description"
            name="description"
            value={event.description}
            onChange={handleChange}
            required
          ></textarea>
        </div>
        <div className="mb-3">
          <label htmlFor="dueDate" className="form-label">
            Due Date
          </label>
          <input
            type="date"
            className="form-control"
            id="dueDate"
            name="dueDate"
            value={event.dueDate}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary">
          Add Event
        </button>
      </form>
    </div>
  );
};

export default AddEvent;
