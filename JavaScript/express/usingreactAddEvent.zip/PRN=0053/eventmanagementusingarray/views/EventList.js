import React, { useState, useEffect } from "react";

const EventList = () => {
  const [events, setEvents] = useState([]);

  useEffect(() => {
    const fetchEventList = async () => {
      try {
        const response = await fetch("http://localhost:3000/events/list");

        if (response.ok) {
          const eventList = await response.json();
          setEvents(eventList);
        } else {
          console.error("Error fetching event list");
        }
      } catch (error) {
        console.error("Error:", error);
      }
    };

    fetchEventList();
  }, []);

  return (
    <div className="container mt-4">
      <h2>Event List</h2>
      <table className="table">
        <thead>
          <tr>
            <th scope="col">Event Title</th>
            <th scope="col">Description</th>
            <th scope="col">Due Date</th>
          </tr>
        </thead>
        <tbody>
          {events.map((event, index) => (
            <tr key={index}>
              <td>{event.title}</td>
              <td>{event.description}</td>
              <td>{event.dueDate}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default EventList;
