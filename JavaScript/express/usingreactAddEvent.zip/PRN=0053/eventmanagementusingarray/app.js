const express = require("express");
const bodyParser = require("body-parser");

const app = express();

app.use(bodyParser.json());

const events = [];

// API to add a new event
app.post("/new", (req, res) => {
  const newEvent = req.body;
  events.push(newEvent);
  res
    .status(201)
    .json({ message: "Event added successfully", event: newEvent });
});

// API to list all events
app.get("/list", (req, res) => {
  res.json(events);
});
app.listen(3000, function () {
  console.log("server is run on port 3000");
});

