const express = require("express");
const router = express.Router();

const events = [];

// Middleware to log requests
router.use((req, res, next) => {
  console.log(`Received ${req.method} request for ${req.url}`);
  next();
});

// Create - Add a new event
router.post("/new", (req, res) => {
  const newEvent = req.body;
  events.push(newEvent);
  res
    .status(201)
    .json({ message: "Event added successfully", event: newEvent });
});

// Read - List all events
router.get("/list", (req, res) => {
  res.json(events);
});

// Update - Edit an existing event
router.put("/update/:eventId", (req, res) => {
  const eventId = req.params.eventId;
  const updatedEvent = req.body;

  const index = events.findIndex((event) => event.id === eventId);
  if (index !== -1) {
    events[index] = { ...events[index], ...updatedEvent };
    res.json({ message: "Event updated successfully", event: events[index] });
  } else {
    res.status(404).json({ error: "Event not found" });
  }
});

// Delete - Remove an event
router.delete("/delete/:eventId", (req, res) => {
  const eventId = req.params.eventId;

  const index = events.findIndex((event) => event.id === eventId);
  if (index !== -1) {
    const deletedEvent = events.splice(index, 1)[0];
    res.json({ message: "Event deleted successfully", event: deletedEvent });
  } else {
    res.status(404).json({ error: "Event not found" });
  }
});

module.exports = router;
