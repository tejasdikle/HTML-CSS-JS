const express = require('express');
const app = express(); // object
const a1 = require("./Stdarr");
//var student = require("express")
const bodyParser = require("body-parser");

app.use(bodyParser.urlencoded({ extended: false }));

// define route
app.get("/", function(req, resp) {
    resp.sendFile("public/form.html", { root: __dirname });
});

app.post("/submit_data", function(req, resp) {
    if (req.body.btn1 == "add") {
        var id = parseInt(req.body.id);
        var stdname = req.body.stdname;
        var std = req.body.std;
        var age = parseInt(req.body.age);
        var marks = parseInt(req.body.marks);
        var place = req.body.place;

        var student = { id, stdname, std, age, marks, place }; // Corrected variable name
        var msg = a1.addstudent(student); // Corrected variable name
        resp.send(`<h3>${msg}</h3>`);
    }
    else{
        var id = parseInt(req.body.id);
        obj = a1.searchstudent(id);
        if(obj!==undefined)
        {
            resp.send(JSON.stringify(obj));

        }
        else{
            console.log("Data Not Found");
            resp.send("<h1>Entry Not Found</h1>");
        }
    }
});

app.listen(3000, function() {
    console.log("Server started on this port no 3000");
});
