stdarr=[];
exports.addstudent=function(obj){

    obj1=stdarr.find(x=>x.id==obj.id);
    if(obj1==null)
    {
        stdarr.push(obj);
        console.log(stdarr);
        return "Student Add successfully";
    }
    else{
        return "Duplicate Student Id ";
    }
}
exports.searchstudent=function(id)
{
    return stdarr.find(x=>x.id==id)
}