import React, { useState, useEffect } from 'react';
import './component/Apps.css';
const TodoApp = () => {
  // State to manage the form input
  const [taskName, setTaskName] = useState('');
  const [taskDuration, setTaskDuration] = useState('');

  // State to manage the list of tasks
  const [tasks, setTasks] = useState([]);

  // Use Effect to load tasks from local storage on component mount
  useEffect(() => {
    const storedTasks = JSON.parse(localStorage.getItem('tasks')) || [];
    setTasks(storedTasks);
  }, []);

  // Function to handle form submission
  const handleAddTask = () => {
    if (taskName && taskDuration) {
      // Create a new task object
      const newTask = { name: taskName, duration: taskDuration };

      // Update the tasks state with the new task
      setTasks([tasks, newTask]);

      // Clear the form input fields
      setTaskName('');
      setTaskDuration('');

      // Update local storage with the new list of tasks
      localStorage.setItem('tasks', JSON.stringify([tasks, newTask]));
    }
  };

  return (
    <div>
      <h2>Todo List</h2>
      <form>
        <label>
            Task Name:
            <input type="text" value={taskName} onChange={(e) => setTaskName(e.target.value)} />
            Task Duration:
            <input type="text" value={taskDuration} onChange={(e) => setTaskDuration(e.target.value)} />        
            <button type="button" onClick={handleAddTask}>Add List</button>
        </label>
      </form><br></br>
      <table border="1px" align='center'>
        <thead>
          <tr>
            <th>Task Name</th>
            <th>Duration</th>
          </tr>
        </thead>
        <tbody>
          {tasks.map((task, index) => (
            <tr key={index}>
              <td>{task.name}</td>
              <td>{task.duration}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TodoApp;
