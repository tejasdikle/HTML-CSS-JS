const express = require("express")
const app = express();

var bodyparser = require("body-parser");// for manage body parsing
//if manage cooki then written cookie parser

//define middleWare
//extended false will use query string module for parsing data coming with url
http://localhost:4000/home?q1=12&q2=23
app.use(bodyparser.urlencoded({extended:false})) // 2 option to write middle ware easy
//this middleware  work with all url



app.get("/",function (req,resp){

    resp.send("<h1>Display form</h1>")
})
app.get("/submit_data",function(req,resp){

    resp.send("<h1>display data</h1>");
})
    
app.listen(4000)
{
    console.log("server run on 4000 port ");
}
