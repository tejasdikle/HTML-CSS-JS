const express = require("express")
const app = express();
var m1=require("./module1");
var bodyparser = require("body-parser");// for manage body parsing
//if manage cooki then written cookie parser

//define middleWare
//extended false will use query string module for parsing data coming with url
http://localhost:4000/home?q1=12&q2=23
app.use(bodyparser.urlencoded({extended:false})) // 2 option to write middle ware easy
//this middleware  work with all url


//convert get to post
app.get("/",function (req,resp){

    resp.sendFile("public/regsitration.html",{root:__dirname})//for current directory 
})
app.post("/submit_data",function(req,resp){
    var num1=req.body.num1;
    var num2=req.body.num2;
    ans=m1.addition(num1,num2);
    resp.send("n1 :" + num1 +" n2 :" + num2+"="+ans)
})
    
app.listen(5000)
{
    console.log("server run on 5000 port ");
}
