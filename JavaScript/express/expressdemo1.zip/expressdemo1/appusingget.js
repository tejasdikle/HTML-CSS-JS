const express = require("express")
const app = express();
var m1=require("./module1");
var bodyparser = require("body-parser");// for manage body parsing
//if manage cooki then written cookie parser

//define middleWare
//extended false will use query string module for parsing data coming with url
http://localhost:4000/home?q1=12&q2=23
app.use(bodyparser.urlencoded({extended:false})) // 2 option to write middle ware easy
//this middleware  work with all url



app.get("/",function (req,resp){

    resp.sendFile("public/login.html",{root:__dirname})//for current directory 
})
app.get("/submit_data",function(req,resp){
    var num1=req.query.num1;
    var num2=req.query.num2;
    ans=m1.addition(num1,num2);
    resp.send("n1 :" + num1 +" n2 :" + num2+"="+ans)
})
    
app.listen(4000)
{
    console.log("server run on 4000 port ");
}
