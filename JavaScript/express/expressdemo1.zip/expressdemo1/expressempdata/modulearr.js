emparr=[];
exports.adddata=function(obj){
    obj1=emparr.find(x=>x.empid==obj.empid);
    if(obj1==null)
    {
    emparr.push(obj);
    console.log(emparr);
    return "added successfully";
    }
    else{
        
        return "duplicate object";
    }
    
}
exports.searchdata=function(empid)
{
    return emparr.find(x=>x.empid==empid)
}