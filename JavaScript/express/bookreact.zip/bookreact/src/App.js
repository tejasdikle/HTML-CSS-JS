// App.js

import React from 'react';
import AddBook from './component/addbook';
import BookList from './component/booklist';
import './component/addbook.css'



const App = () => {
  const handleAddBook = (book) => {
    // Your logic to add the book (e.g., AJAX request, local storage) goes here
    console.log('Book added:', book);
  };

  return (
    <div>
      <h1>Book App</h1>
      <AddBook onAddBook={handleAddBook} />
      <BookList />
    </div>
  );
};

export default App;
