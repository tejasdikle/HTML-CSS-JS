// AddBook.js

import React, { useState } from 'react';

const AddBook = ({ onAddBook }) => {
  const [book, setBook] = useState({ name: '', author: '', price: '' });

  const handleChange = (e) => {
    setBook({ ...book, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onAddBook(book);
    setBook({ name: '', author: '', price: '' });
  };

  return (
    <div>
      <h2>Add Book</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Book Name:
          <input type="text" name="name" value={book.name} onChange={handleChange} />
        </label>
        <br />
        <label>
          Author:
          <input type="text" name="author" value={book.author} onChange={handleChange} />
        </label>
        <br />
        <label>
          Price:
          <input type="text" name="price" value={book.price} onChange={handleChange} />
        </label>
        <br />
        <button type="submit">Add</button>
      </form>
    </div>
  );
};

export default AddBook;
