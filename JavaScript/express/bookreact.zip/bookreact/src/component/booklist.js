// BookList.js

import React from 'react';

const BookList = () => {
  const books = JSON.parse(localStorage.getItem('books')) || [];

  return (
    <div>
      <h2>Book List</h2>
      {books.length === 0 ? (
        <p>No books available.</p>
      ) : (
        <table style={{ borderCollapse: 'collapse', width: '100%' }}>
          <thead>
            <tr>
              <th style={cellStyle}>Book Name</th>
              <th style={cellStyle}>Author</th>
              <th style={cellStyle}>Price</th>
            </tr>
          </thead>
          <tbody>
            {books.map((book, index) => (
              <tr key={index}>
                <td style={cellStyle}>{book.name}</td>
                <td style={cellStyle}>{book.author}</td>
                <td style={cellStyle}>{book.price}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};
const cellStyle = {
    border: '2px solid black',
    padding: '8px',
  };
  
export default BookList;
